
  # Chat Authentication App

  This is a code bundle for Chat Authentication App. The original project is available at https://www.figma.com/design/kkODsFc51gg4NqGhfLd8JY/Chat-Authentication-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  